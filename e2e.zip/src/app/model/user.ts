export class User {
    nama: string;
    email: string;
    location: string[];
    constructor(nama: string, email: string, location: string[]){

    }
}
