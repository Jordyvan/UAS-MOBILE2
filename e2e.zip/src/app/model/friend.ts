export class Friend{
    nama: string;
    value: boolean;
}
